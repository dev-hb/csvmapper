<?php


ini_set('display_errors', 1); ini_set('display_startup_errors', 1); error_reporting(E_ALL);

const DATA_DIR = "data/";
const OUTPUT_DIR = "output/";

$SEPARATOR = ";";

require_once 'autoload.php';



